package edu.thkoeln.itsec.verschluesselung.symmetrisch;

import java.io.File;

/**
 * Class to symmetrically encrypt and decrypt a file using the AES algorithm.
 *
 * @author
 */
public class SymmetricEncryptor extends AbstractSymmetricEncryptor {

    public SymmetricEncryptor(String algorithm, boolean loadConfig) {
        super(algorithm, loadConfig);
    }

    @Override
    public void encryptFile(File inputFile, File outputFile) throws Exception {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void decryptFile(File inputFile, File outputFile) throws Exception {
        throw new UnsupportedOperationException("Not supported yet.");
    }

}
