package edu.thkoeln.itsec.verschluesselung.asymmetrisch;

import java.security.PublicKey;

/**
 *
 * @author 
 */
public class RsaCommunicationPartner extends AbstractRsaCommunicationPartner {
    
    public RsaCommunicationPartner() throws Exception {
        super();
    }

    @Override
    public byte[] encryptMessage(String message) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); 
    }

    @Override
    public String decryptMessage(byte[] ciphertext) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); 
    }

    @Override
    public void setPartnerKey(PublicKey partnerKey) {
        throw new UnsupportedOperationException("Not supported yet."); 
    }

    @Override
    public PublicKey getPublicKey() {
        throw new UnsupportedOperationException("Not supported yet."); 
    }

    @Override
    public byte[] comupteCryptographicHash(byte[] bytes) throws Exception {
        // Needed for assignment 3.
        throw new UnsupportedOperationException("Not supported yet."); 
    }

    @Override
    public byte[] signData(byte[] bytes) throws Exception {
        // Needed for assignment 3.
        throw new UnsupportedOperationException("Not supported yet."); 
    }

    @Override
    public boolean verifySignature(byte[] signatureBytes, byte[] messageBytes) throws Exception {
        // Needed for assignment 3.
        throw new UnsupportedOperationException("Not supported yet."); 
    }
    
}
